var elements = document.getElementsByTagName('*');

for (var i = 0; i < elements.length; i++) {
    var element = elements[i];

    for (var j = 0; j < element.childNodes.length; j++) {
        var node = element.childNodes[j];

        if (node.nodeType === 3) {
            var text = node.nodeValue;
            var replacedText = text.replace(/Thomas/gi, 'Tchongass');

            if (replacedText !== text) {
                element.replaceChild(document.createTextNode(replacedText), node);
			}
				
            
        }
		
    }
}

for (var i = 0; i < elements.length; i++) {
    var element = elements[i];

    for (var j = 0; j < element.childNodes.length; j++) {
        var node = element.childNodes[j];

        if (node.nodeType === 3) {
            var text = node.nodeValue;
            var replacedText = text.replace(/Pazinato/gi, 'Pica');

            if (replacedText !== text) {
                element.replaceChild(document.createTextNode(replacedText), node);
			}
				
            
        }
		
    }
}
for (var i = 0; i < elements.length; i++) {
    var element = elements[i];

    for (var j = 0; j < element.childNodes.length; j++) {
        var node = element.childNodes[j];

        if (node.nodeType === 3) {
            var text = node.nodeValue;
            var replacedText = text.replace(/Bocalon/gi, 'Foda');

            if (replacedText !== text) {
                element.replaceChild(document.createTextNode(replacedText), node);
			}
				
            
        }
		
    }
}
for (var i = 0; i < elements.length; i++) {
    var element = elements[i];

    for (var j = 0; j < element.childNodes.length; j++) {
        var node = element.childNodes[j];

        if (node.nodeType === 3) {
            var text = node.nodeValue;
            var replacedText = text.replace(/Luíza/gi, 'Fa de one Directionkkkkkk');

            if (replacedText !== text) {
                element.replaceChild(document.createTextNode(replacedText), node);
			}
				
            
        }
		
    }
}

for (var i = 0; i < elements.length; i++) {
    var element = elements[i];

    for (var j = 0; j < element.childNodes.length; j++) {
        var node = element.childNodes[j];

        if (node.nodeType === 3) {
            var text = node.nodeValue;
            var replacedText = text.replace(/Luca/gi, 'Luca(Atrasado)');

            if (replacedText !== text) {
                element.replaceChild(document.createTextNode(replacedText), node);
			}
				
            
        }
		
    }
}


for (var i = 0; i < elements.length; i++) {
    var element = elements[i];

    for (var j = 0; j < element.childNodes.length; j++) {
        var node = element.childNodes[j];

        if (node.nodeType === 3) {
            var text = node.nodeValue;
            var replacedText = text.replace(/Coimbra/gi, 'InnerBloom');

            if (replacedText !== text) {
                element.replaceChild(document.createTextNode(replacedText), node);
			}
				
            
        }
		
    }
}

for (var i = 0; i < elements.length; i++) {
    var element = elements[i];

    for (var j = 0; j < element.childNodes.length; j++) {
        var node = element.childNodes[j];

        if (node.nodeType === 3) {
            var text = node.nodeValue;
            var replacedText = text.replace(/da Costa/gi, 'Carro');

            if (replacedText !== text) {
                element.replaceChild(document.createTextNode(replacedText), node);
			}
				
            
        }
		
    }
}

for (var i = 0; i < elements.length; i++) {
    var element = elements[i];

    for (var j = 0; j < element.childNodes.length; j++) {
        var node = element.childNodes[j];

        if (node.nodeType === 3) {
            var text = node.nodeValue;
            var replacedText = text.replace(/Tieppo/gi, '"vou te quebrar na porrada"');

            if (replacedText !== text) {
                element.replaceChild(document.createTextNode(replacedText), node);
			}
				
            
        }
		
    }
}